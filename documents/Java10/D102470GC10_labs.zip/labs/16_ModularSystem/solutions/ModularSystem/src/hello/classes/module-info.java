/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */

module hello {
    requires  people;
}
