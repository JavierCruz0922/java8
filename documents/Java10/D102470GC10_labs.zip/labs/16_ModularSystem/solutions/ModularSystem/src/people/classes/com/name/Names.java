/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */

package com.name;

public class Names {
    public static String getName(){
        return "Duke!";
    }
}