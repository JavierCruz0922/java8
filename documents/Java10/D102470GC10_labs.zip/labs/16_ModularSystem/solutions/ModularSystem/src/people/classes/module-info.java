/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */

module people {
    exports com.name;
    requires transitive conversation;
}
