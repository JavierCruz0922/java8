/* Copyright © 2018 Oracle and/or its affiliates. All rights reserved. */

package exercise_04_1;

public class ShoppingCart {
    public static void main(String[] args){
        // Declare and initialize String variables.  Do not initialize message yet.
        
        // Assign the message variable 
        
        // Print and run the code

    }
}
