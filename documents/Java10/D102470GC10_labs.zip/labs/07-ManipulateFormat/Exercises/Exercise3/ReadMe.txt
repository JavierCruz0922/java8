Exercise 7-3

1. Declare a long, using the L to indicate a long value.  Make it a 
     very large number (in the billions).
2. Declare and initialize a float and a char.
3. Print the long variable with a suitable label.
4. Assign the long to the int variable.  Correct the syntax error
     by casting the long as an int.
5. Print the int variable.  Note the change in value when you run it.