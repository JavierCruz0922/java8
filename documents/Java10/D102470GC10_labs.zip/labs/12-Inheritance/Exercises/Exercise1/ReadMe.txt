Exercise 12-1

1.  Examine the Item class.  Pay close attention to the 
      overloaded constructor and also the display method.
2.  Create a new class called Shirt that inherits from Item.
3.  Declare two private char fields: size and colorCode
4.  Create a constructor method that takes 3 args(price, size, colorCode).  
5.  The constructor should:
	- Call the 2-arg constructor in the superclass, sending a String 
            literal for the desc arg ("Shirt") and pass the price argument 
            from this constructor. 
	-  Assign the size and colorCode fields.

In the ShoppingCart class, 
6.  Declare and instantiate a Shirt object, using the 3 arg constructor.
7.  Call the display() method on the object reference. 
      Where is the display method coded?
