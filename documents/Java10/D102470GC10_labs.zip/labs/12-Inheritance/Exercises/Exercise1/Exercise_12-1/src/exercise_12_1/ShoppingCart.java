/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package exercise_12_1;

public class ShoppingCart {
    public static void main(String args[]){ 
	// Instantiate a Shirt object and call display() on the object reference
        
       
    }
}    
